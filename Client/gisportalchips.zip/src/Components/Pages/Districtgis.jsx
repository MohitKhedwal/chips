import React from 'react'

function Districtgis() {
  return (
    <div>
      <h1 className='font-bold text-center'> THIS IS DISTRICT GIS</h1>
    </div>
  )
}

export default Districtgis
