import React from 'react'

function Data() {
  return (
    <div>
      <h1 className='text-center font-bold'>THIS IS DATA PAGE</h1>
    </div>
  )
}

export default Data
