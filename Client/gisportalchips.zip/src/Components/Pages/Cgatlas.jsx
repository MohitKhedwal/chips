import React from 'react'

function Cgatlas() {
  return (
    <div>
      <h1 className='text-center font-bold'> THIS IS CG ATLAS</h1>
    </div>
  )
}

export default Cgatlas
