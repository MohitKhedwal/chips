import React from 'react'

function Stategis() {
  return (
    <div>
      <h1 className='text-center font-bold'>THIS IS STATE GIS PORTAL</h1>
    </div>
  )
}

export default Stategis
